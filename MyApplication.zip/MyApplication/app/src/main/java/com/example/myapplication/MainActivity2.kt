package com.example.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AlertDialog
import com.example.myapplication.databinding.ActivityMain2Binding

class MainActivity2 : AppCompatActivity() {
    private lateinit var binding: ActivityMain2Binding
    private var rightAnswerCount=0
    private var quizCount=1
    private val QUIZCOUNT=10

    private val quizData= mutableListOf(
        mutableListOf<String>("Quanti fusi orari ci sono in Russia”","10","15", "2", "11"),
        mutableListOf<String>("Qual è l’animale nazionale dell’Australia","Canguro rosso","Toro", "Elefante", "Falena barboncino"),
        mutableListOf<String>("Quanti giorni ci vogliono affinché la Terra orbiti attorno al Sole","400", "365", "97", "267"),
        mutableListOf<String>("Fino al 1923, come si chiamava la città turca di Istanbul","Costantinopoli","Copenaghen", "Barcinone", "Tarsatica"),
        mutableListOf<String>("Qual è la capitale del Canada","Toronto","Montréal ","Ottawa",  "Calgary"),
        mutableListOf<String>("Qual è il fiume più lungo del mondo","Rio delle Amazzoni", "Fiume Azzurro", "Mississippi","Nilo"),
        mutableListOf<String>("Quale famoso artista di graffiti viene da Bristol","Picasso","Frida Kahlo", "Banksy", "Andy Warhol"),
        mutableListOf<String>("Dove si sono svolti i primi giochi olimpici moderni","Atene", "Patrasso", "Pireo","Salonicco"),
        mutableListOf<String>("Quando è stata fondata Netflix","1997","2001", "2009", "2015"),
        mutableListOf<String>("Chi ha inventato il World Wide Web","Mark Zuckerberg", "Bill Gates","Steve Jobs", "Tim Berners-Lee")
    );
    private val risposte= mutableListOf("11","Canguro rosso","365","Costantinopoli","Ottawa", "Nilo", "Banksy","Atene","1997","Tim Berners-Lee");
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMain2Binding.inflate(layoutInflater)
        val view=binding.root
        setContentView(view)



        showNextQuiz()
    }
    fun showNextQuiz(){
        val quiz=quizData[0]

        binding.question.text=quiz[0]

        quiz.removeAt(0)

        binding.answer1.text=quiz[0]
        binding.answer2.text=quiz[1]
        binding.answer3.text=quiz[2]
        binding.answer4.text=quiz[3]

        quizData.removeAt(0)

    }
    fun checkAnswer(view: View){


        val answerbtn: Button =findViewById(view.id)
        val btntext=answerbtn.text.toString()
        val alertTitle:String
        if(btntext==risposte[0]){
            alertTitle="CORRETTO"
            rightAnswerCount++

        }else{
            alertTitle="SBAGLIATO"

        }
        risposte.removeAt(0)

        AlertDialog.Builder(this)
            .setTitle(alertTitle)
            .setPositiveButton("OK"){dialogInterface, i ->
                checkQuizCount()
            }
            .setCancelable(false)
            .show()

    }
    fun checkQuizCount(){
        if(quizCount==QUIZCOUNT){
            val intent= Intent(this@MainActivity2,resultActivity::class.java)
            intent.putExtra("RIGHT_ANSWER_COUNT", rightAnswerCount)
            startActivity(intent)

        }else{
            quizCount++
            showNextQuiz()

        }

    }
}
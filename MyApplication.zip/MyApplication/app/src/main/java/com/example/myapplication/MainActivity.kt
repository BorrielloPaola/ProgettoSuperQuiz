package com.example.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AlertDialog
import com.example.myapplication.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    private var rightAnswerCount=0
    private var quizCount=1
    private val QUIZCOUNT=10

    private val quizData= mutableListOf(
        mutableListOf<String>("In quale città ha sede il festival della musica dance ed elettronica “Tomorrowland”","Boom","Parigi", "Amsterdam", "Madrid"),
        mutableListOf<String>("Chi ha vinto il Festival di Sanremo 2012?","Simone Cristicchi","Marco Carta", "Emma", "Povia "),
        mutableListOf<String>("Nel moderno sistema musicale, quante sono, in tutto, le tonalità maggiori e minori","Dodici", "Venti", "Trentasei", "Ventiquattro"),
        mutableListOf<String>("Qual è stato il primo successo dei Beatles","Imagine","Let it be", "Love me do", "We can work it out"),
        mutableListOf<String>("Il segno che comunemente chiamiamo hashtag, # ( cancelletto), in musica cosa significa","Diesis","Bequadro","Corona",  "Bemolle"),
        mutableListOf<String>("Chi cantava Le mille bolle blu","Donatella Rettore", "Marcella Bella", "Raffaella Carrà","Mina"),
        mutableListOf<String>("Chi erano i Blues Brothers","Totò e Peppino","John Belushi e Dan Aykroyd", "Boldi e De Sica", "Stanlio e Ollio"),
        mutableListOf<String>("Quale band rock canta Satisfaction","Led Zeppelin", "Metallica", "Rolling Stones","Kiss"),
        mutableListOf<String>("Chi ha dedicato una canzone alla Coca-Cola","Whitney Houston","Vasco Rossi", "Frank Sinatra", "Ray Charles"),
        mutableListOf<String>("In quale città è nato il compositore Antonio Vivaldi","Venezia", "Treviso","Roma",  "Livorno")
    );
    private val risposte= mutableListOf("Boom","Emma","Ventiquattro","Love me do","Diesis", "Mina", "John Belushi e Dan Aykroyd","Rolling Stones","Vasco Rossi","Venezia");
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        val view=binding.root
        setContentView(view)



        showNextQuiz()
    }
    fun showNextQuiz(){
        val quiz=quizData[0]

        binding.question.text=quiz[0]

        quiz.removeAt(0)

        binding.answer1.text=quiz[0]
        binding.answer2.text=quiz[1]
        binding.answer3.text=quiz[2]
        binding.answer4.text=quiz[3]

        quizData.removeAt(0)

    }
    fun checkAnswer(view:View){

        val answerbtn:Button=findViewById(view.id)
        val btntext=answerbtn.text.toString()
        val alertTitle:String
        if(btntext==risposte[0]){
            alertTitle="CORRETTO"
            rightAnswerCount++

        }else{
            alertTitle="SBAGLIATO"

        }
        risposte.removeAt(0)

        AlertDialog.Builder(this)
            .setTitle(alertTitle)
            .setPositiveButton("OK"){dialogInterface, i ->
                checkQuizCount()
            }
            .setCancelable(false)
            .show()

    }
    fun checkQuizCount(){
        if(quizCount==QUIZCOUNT){
            val intent=Intent(this@MainActivity,resultActivity::class.java)
            intent.putExtra("RIGHT_ANSWER_COUNT", rightAnswerCount)
            startActivity(intent)

        }else{
            quizCount++
            showNextQuiz()

        }

    }
}

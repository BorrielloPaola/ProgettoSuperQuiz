package com.example.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AlertDialog
import com.example.myapplication.databinding.ActivityMain3Binding

class MainActivity3 : AppCompatActivity() {
    private lateinit var binding: ActivityMain3Binding
    private var rightAnswerCount=0
    private var quizCount=1
    private val QUIZCOUNT=10

    private val quizData= mutableListOf(
        mutableListOf<String>("Nel film I Pirati dei Caraibi che cosa è raffigurato al centro del medaglione pirata","Vascello","Benda", "Teschio", "Uncino"),
        mutableListOf<String>("Nel film Mamma ho perso l’aereo, la famiglia è in partenza per le vacanze di Natale. Dove sono diretti","Mosca","Parigi", "Berlino", "Roma"),
        mutableListOf<String>("Su quale dio della mitologia è basato il personaggio di re Tritone padre della sirenetta","Efesto", "Apollo", "Ermes", "Poseidone"),
        mutableListOf<String>("Nel film Avatar, il protagonista deve affrontare un viaggio lungo anni luce per raggiungere quale destinazione","Pandora","Paititi", "Scholomance", "Agartha "),
        mutableListOf<String>("Quale supereroe Marvel utilizza la super armatura Hulkbuste","Ironman","Hulk","Capitan America",  "Spiderman"),
        mutableListOf<String>("Qual è il primo film di animazione della storia che fu candidato all'Oscar come miglior film","Biancaneve", "La sirenetta", "La bella e la bestia","Mulan"),
        mutableListOf<String>("Quante volte si sposa la protagonista del film Via col vento, Rossella O’Hara","3","7", "1", "2"),
        mutableListOf<String>("Che colore è presente in quasi ogni scatto di Shining","Giallo", "Rosso", "Nero","Verde"),
        mutableListOf<String>("Quale film è stato erroneamente annunciato come il vincitore del miglior film agli Oscar del 2017","The Greatest showman","Wonder", "Chiamami col tuo nome", "La La Land"),
        mutableListOf<String>("Quale passo della Bibbia cita sempre Jules Winnfield in Pulp Fiction", "Ezekiel 25 32", "Ezekiel 25 7","Ezekiel 25 17", "Ezekiel 24 17")
    );
    private val risposte= mutableListOf("Teschio","Parigi","Poseidone","Pandora","Ironman", "La bella e la bestia", "3","Rosso","La La Land","Ezekiel 25 17");
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMain3Binding.inflate(layoutInflater)
        val view=binding.root
        setContentView(view)



        showNextQuiz()
    }
    fun showNextQuiz(){
        val quiz=quizData[0]

        binding.question.text=quiz[0]

        quiz.removeAt(0)

        binding.answer1.text=quiz[0]
        binding.answer2.text=quiz[1]
        binding.answer3.text=quiz[2]
        binding.answer4.text=quiz[3]

        quizData.removeAt(0)

    }
    fun checkAnswer(view: View){


        val answerbtn: Button =findViewById(view.id)
        val btntext=answerbtn.text.toString()
        val alertTitle:String
        if(btntext==risposte[0]){
            alertTitle="CORRETTO"
            rightAnswerCount++

        }else{
            alertTitle="SBAGLIATO"

        }
        risposte.removeAt(0)

        AlertDialog.Builder(this)
            .setTitle(alertTitle)
            .setPositiveButton("OK"){dialogInterface, i ->
                checkQuizCount()
            }
            .setCancelable(false)
            .show()

    }
    fun checkQuizCount(){
        if(quizCount==QUIZCOUNT){
            val intent= Intent(this@MainActivity3,resultActivity::class.java)
            intent.putExtra("RIGHT_ANSWER_COUNT", rightAnswerCount)
            startActivity(intent)

        }else{
            quizCount++
            showNextQuiz()

        }

    }
}
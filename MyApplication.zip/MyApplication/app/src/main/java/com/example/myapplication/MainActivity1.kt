package com.example.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.myapplication.databinding.ActivityMain1Binding

class MainActivity1 : AppCompatActivity() {
    private lateinit var binding: ActivityMain1Binding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding= ActivityMain1Binding.inflate(layoutInflater)
        val view =binding.root
        setContentView(view)



        binding.materia1.setOnClickListener{
            startActivity((Intent(this@MainActivity1, MainActivity::class.java)))

        }
        binding.materia2.setOnClickListener{
            startActivity((Intent(this@MainActivity1, MainActivity2::class.java)))

        }

        binding.materia3.setOnClickListener{
            startActivity((Intent(this@MainActivity1, MainActivity3::class.java)))

        }
    }
}

